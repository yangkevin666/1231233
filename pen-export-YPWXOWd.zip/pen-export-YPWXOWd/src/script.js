let startTime = 0;
let canStop = false;
let timer = null;

function startTest() {
    document.body.style.backgroundColor = "red";
    document.getElementById("message").innerText = "等待中...";
    canStop = false;

    // 隨機延遲 1～5 秒
    let delay = Math.random() * 4000 + 1000;

    timer = setTimeout(() => {
        document.body.style.backgroundColor = "green";
        document.getElementById("message").innerText = "快按停止！";
        startTime = Date.now();
        canStop = true;
    }, delay);
}

function stopTest() {
    if (!canStop) {
        document.getElementById("message").innerText = "太早按了！";
        clearTimeout(timer);
        return;
    }

    let reactionTime = Date.now() - startTime;
    document.getElementById("message").innerText =
        "你的反應時間是 " + reactionTime + " 毫秒";

    canStop = false;
}